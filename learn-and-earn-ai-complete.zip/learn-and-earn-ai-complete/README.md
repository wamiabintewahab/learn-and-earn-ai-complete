# Learn and Earn AI — consolidated foundation

## Pages
Home, learning roadmap, video library layout, JavaScript playground, project studio, About, Privacy, Security, Login, Sign up, Password recovery.

## Preview locally
Open `public/index.html` in a modern browser. Best: use VS Code Live Server. Shared CSS/JS live in `public/assets/`.

## Publish on GitHub Pages
Upload the **contents of `public/`** into the repository root so `index.html` is at the root and `assets/` remains a folder. Commit to `main`. Then open **Settings → Pages → Deploy from a branch → main → /(root) → Save**.

## Honest production status
This is a substantial frontend foundation, not a production-complete service:
- Auth screens do not create accounts or send verification/reset emails.
- No database or authentication provider is connected.
- Video cards are placeholders; no video playback or live stream is connected.
- The playground executes JavaScript in the page context and is NOT a secure sandbox.
- Python, Java, C/C++, and other runtimes are not integrated.
- Privacy is a draft and requires review against actual data flows.

## Production architecture to implement
Use a managed auth/database provider (for example, Supabase) with email verification, password recovery, access policies and row-level security. Deploy the frontend and server/API to a suitable host. Use environment variables for secrets. Run arbitrary code only in isolated workers/containers with CPU, memory, time, filesystem and network limits. Connect a licensed video host; live streaming needs a separate provider. Test authorization boundaries, deletion, backups, rate limiting, HTTPS, security headers, monitoring and privacy behavior before launch.
